<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tourist_attractions', function (Blueprint $table) {
            $table->json('gallery')->nullable()->change();
        });
    }

    public function down(): void
    {
        Schema::table('tourist_attractions', function (Blueprint $table) {
            $table->longText('gallery')->nullable()->change();
        });
    }
};
